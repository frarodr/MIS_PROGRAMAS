package figuras;
public class Cuadrado extends Poligono{
    public void dibujar(){
        System.out.println("Cuadrado.Dibujar()");
    }
    public void borrar(){
        System.out.println("Cuadrado.Borrar()");
    }
    
}
