package figuras;
public abstract class Poligono {
    public void dibujar(){
        System.out.println("Poligono.dibujar()");
    }
    public abstract void borrar();           
}