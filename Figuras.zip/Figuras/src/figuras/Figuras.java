package figuras;
public class Figuras {
    public static void main(String[] args) {
        Poligono [] s = new Poligono [9];
        for (int i=0; i<s.length;i++){
            s[i]=poligonoAleatorio();            
        }
        for (int i=0; i<s.length;i++){
            s[i].dibujar();
            s[i].borrar();
        }
    }
    public static Poligono poligonoAleatorio(){
        Poligono p;
        switch ((int) (Math.random()*3)){
            case 0: p = new Circulo();break;
            case 1: p = new Cuadrado();break;
            case 2: p = new Triangulo();break;
            default: p = new Circulo();break;
        }
        return p;
    }
}

