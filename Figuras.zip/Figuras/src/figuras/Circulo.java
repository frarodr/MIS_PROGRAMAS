package figuras;
public class Circulo extends Poligono{
    public void dibujar(){
        System.out.println("Circulo.Dibujar()");
    }
    public void borrar(){
        System.out.println("Circulo.Borrar()");
    }
}
